package com.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT
private const val SOFT_WHITE = 0xFFD5D8F0.toInt()

class AuroraView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, rgb: Int, alpha: Int) {
        val center = (rgb and 0x00FFFFFF) or (alpha shl 24)
        val edge = rgb and 0x00FFFFFF
        paint.shader = RadialGradient(x, y, r, center, edge, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF0A0B1E.toInt())
        glow(c, w * 0.08f, 0f, w * 0.55f, 0x6D28D9, 150)
        glow(c, w, h, w * 0.55f, 0x0EA5E9, 110)
        glow(c, w * 0.6f, h * 0.45f, w * 0.35f, 0xDB2777, 60)
    }
}

class AppItem(val pkg: String, val label: String, val icon: Drawable, val intent: Intent)

class MainActivity : Activity() {

    private lateinit var content: LinearLayout
    private var apps: List<AppItem> = emptyList()
    private var showHidden = false
    private var firstTile: View? = null

    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private fun getSet(key: String): MutableSet<String> =
        HashSet(prefs.getStringSet(key, emptySet()) ?: emptySet())

    private fun putSet(key: String, set: Set<String>) {
        prefs.edit().putStringSet(key, set).apply()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.addView(AuroraView(this), FrameLayout.LayoutParams(MP, MP))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(32), dp(56), dp(24))
        }
        root.addView(content, FrameLayout.LayoutParams(MP, MP))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        apps = loadApps()
        render()
    }

    override fun onBackPressed() {
        if (showHidden) {
            showHidden = false
            render()
        }
        // On the home screen, Back does nothing.
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val seen = HashSet<String>()
        val out = ArrayList<AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg)
                    ?: continue
                out.add(AppItem(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), launch))
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    private fun render() {
        content.removeAllViews()
        firstTile = null
        val hidden = getSet("hidden")
        val favs = getSet("fav")
        val visible = apps.filter { it.pkg !in hidden }
        val favApps = visible.filter { it.pkg in favs }

        // Top bar: clock, date, hidden-apps chip
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "H:mm"
            textSize = 56f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        })
        left.addView(TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"
            format24Hour = "EEEE, d MMMM"
            textSize = 16f
            setTextColor(SOFT_WHITE)
        })
        top.addView(left, LinearLayout.LayoutParams(0, WC, 1f))
        top.addView(chip(if (showHidden) "Back to home" else "${hidden.size} apps hidden") {
            showHidden = !showHidden
            render()
        })
        content.addView(top, LinearLayout.LayoutParams(MP, WC))

        // Favorites
        content.addView(sectionTitle("Favorites"))
        if (favApps.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "Hold OK on any app to add it here"
                textSize = 16f
                setTextColor(SOFT_WHITE)
                setPadding(dp(8), dp(40), dp(8), dp(40))
            })
        } else {
            content.addView(row(favApps, 120))
        }

        // All apps (or hidden apps)
        val list = if (showHidden) apps.filter { it.pkg in hidden } else visible
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(8))
            background = GradientDrawable().apply {
                setColor(0x22FFFFFF)
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), 0x33FFFFFF)
            }
        }
        panel.addView(sectionTitle(if (showHidden) "Hidden apps (hold OK to unhide)" else "All apps"))
        panel.addView(row(list, 84))
        content.addView(panel, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(16) })

        firstTile?.requestFocus()
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(8), dp(16), dp(8), dp(4))
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val bg = GradientDrawable().apply {
            setColor(0x33FFFFFF)
            cornerRadius = dp(40).toFloat()
            setStroke(dp(1), 0x44FFFFFF)
        }
        return TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            background = bg
            isFocusable = true
            isClickable = true
            setOnClickListener { onClick() }
            setOnFocusChangeListener { _, f ->
                bg.setColor(if (f) Color.WHITE else 0x33FFFFFF)
                setTextColor(if (f) 0xFF0A0B1E.toInt() else Color.WHITE)
            }
        }
    }

    private fun row(items: List<AppItem>, size: Int): HorizontalScrollView {
        val sv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
        }
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(12), dp(8), dp(12))
            clipChildren = false
        }
        for (item in items) {
            ll.addView(tile(item, size), LinearLayout.LayoutParams(WC, WC).apply {
                rightMargin = dp(18)
            })
        }
        sv.addView(ll)
        return sv
    }

    private fun tile(app: AppItem, size: Int): View {
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0x66FFFFFF, 0x1AFFFFFF)
        ).apply {
            cornerRadius = dp(size / 4).toFloat()
            setStroke(dp(1), 0x33FFFFFF)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true
            isClickable = true
        }
        val box = FrameLayout(this).apply { background = bg }
        val img = ImageView(this).apply {
            setImageDrawable(app.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(size / 6), dp(size / 6), dp(size / 6), dp(size / 6))
        }
        box.addView(img, FrameLayout.LayoutParams(MP, MP))
        col.addView(box, LinearLayout.LayoutParams(dp(size), dp(size)))
        val label = TextView(this).apply {
            text = app.label
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setTextColor(SOFT_WHITE)
            setPadding(0, dp(8), 0, 0)
        }
        col.addView(label, LinearLayout.LayoutParams(dp(size), WC))

        col.setOnClickListener { startActivity(app.intent) }
        col.setOnLongClickListener { showMenu(app); true }
        col.setOnFocusChangeListener { v, f ->
            val s = if (f) 1.12f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(140).start()
            bg.setStroke(if (f) dp(3) else dp(1), if (f) Color.WHITE else 0x33FFFFFF)
            label.setTextColor(if (f) Color.WHITE else SOFT_WHITE)
            label.typeface = if (f) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        if (firstTile == null) firstTile = col
        return col
    }

    private fun showMenu(app: AppItem) {
        val favs = getSet("fav")
        val hidden = getSet("hidden")
        val isFav = app.pkg in favs
        val isHidden = app.pkg in hidden
        val options = arrayOf(
            if (isFav) "Remove from favorites" else "Add to favorites",
            if (isHidden) "Unhide app" else "Hide app"
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(options) { _, which ->
                if (which == 0) {
                    if (isFav) favs.remove(app.pkg) else favs.add(app.pkg)
                    putSet("fav", favs)
                } else {
                    if (isHidden) hidden.remove(app.pkg) else hidden.add(app.pkg)
                    putSet("hidden", hidden)
                }
                render()
            }
            .show()
    }
}
