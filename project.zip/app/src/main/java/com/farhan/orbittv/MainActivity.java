package com.farhan.orbittv;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int WHITE = Color.rgb(247, 249, 255);
    private final int MUTED = Color.rgb(160, 174, 198);
    private final Handler handler = new Handler();
    private TextView clockView;
    private LinearLayout appRow;
    private final List<ResolveInfo> apps = new ArrayList<>();
    private ToneGenerator tone;
    private long lastFocusTone = 0;

    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            if (clockView != null) {
                clockView.setText(new SimpleDateFormat("h:mm a  •  EEE, d MMM", Locale.getDefault()).format(new Date()));
            }
            handler.postDelayed(this, 30000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 32); } catch (Exception ignored) {}
        hideSystemUi();
        buildScreen();
        loadApps();
        handler.post(clockTick);
    }

    @Override protected void onResume() {
        super.onResume();
        hideSystemUi();
        if (appRow != null) loadApps();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(clockTick);
        if (tone != null) { tone.release(); tone = null; }
        super.onDestroy();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable shape(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(42), dp(22), dp(42), dp(22));
        root.setBackgroundResource(R.drawable.bg_main);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = label("orbit", 27, WHITE, true);
        brand.setLetterSpacing(-0.04f);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(46), 1));

        TextView nav = label("WATCH NOW     MOVIES     SHOWS     APPS", 12, MUTED, true);
        nav.setLetterSpacing(0.08f);
        top.addView(nav, new LinearLayout.LayoutParams(-2, dp(46)));

        clockView = label("", 14, WHITE, false);
        clockView.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(190), dp(46));
        cp.leftMargin = dp(24);
        top.addView(clockView, cp);
        root.addView(top);

        ScrollView page = new ScrollView(this);
        page.setFillViewport(false);
        page.setClipToPadding(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(18), 0, dp(8));

        // Large cinematic hero panel.
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(30), dp(22), dp(30), dp(22));
        hero.setBackground(shape(Color.rgb(28, 42, 67), 24, Color.rgb(55, 77, 111), 1));
        TextView eyebrow = label("YOUR PERSONAL TV SPACE", 11, Color.rgb(132, 211, 255), true);
        eyebrow.setLetterSpacing(0.16f);
        hero.addView(eyebrow, new LinearLayout.LayoutParams(-1, dp(24)));

        TextView headline = label("Everything you love.", 31, WHITE, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(45));
        hp.topMargin = dp(5);
        hero.addView(headline, hp);

        TextView description = label("Your apps. Your screen. No ads.", 15, Color.rgb(198, 211, 231), false);
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(-1, dp(30));
        hero.addView(description, dp2);

        TextView hint = label("Select an app below to get started  →", 13, Color.rgb(132, 211, 255), true);
        LinearLayout.LayoutParams hintp = new LinearLayout.LayoutParams(-1, dp(26));
        hintp.topMargin = dp(8);
        hero.addView(hint, hintp);

        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(-1, dp(190));
        content.addView(hero, heroParams);

        TextView section = label("Your apps", 20, WHITE, true);
        LinearLayout.LayoutParams sectionParams = new LinearLayout.LayoutParams(-1, dp(42));
        sectionParams.topMargin = dp(18);
        content.addView(section, sectionParams);

        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        horizontal.setHorizontalScrollBarEnabled(false);
        horizontal.setClipToPadding(false);
        appRow = new LinearLayout(this);
        appRow.setOrientation(LinearLayout.HORIZONTAL);
        appRow.setPadding(dp(3), dp(8), dp(18), dp(14));
        horizontal.addView(appRow, new HorizontalScrollView.LayoutParams(-2, -2));
        content.addView(horizontal, new LinearLayout.LayoutParams(-1, dp(145)));

        TextView footer = label("Navigate with your remote  •  OK to open  •  BACK to return", 12, Color.rgb(112, 132, 160), false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(30));
        fp.topMargin = dp(8);
        content.addView(footer, fp);

        page.addView(content);
        root.addView(page, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void loadApps() {
        if (appRow == null) return;
        appRow.removeAllViews();
        apps.clear();
        PackageManager pm = getPackageManager();

        Intent tv = new Intent(Intent.ACTION_MAIN);
        tv.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        addUnique(pm.queryIntentActivities(tv, PackageManager.MATCH_ALL));

        Intent normal = new Intent(Intent.ACTION_MAIN);
        normal.addCategory(Intent.CATEGORY_LAUNCHER);
        addUnique(pm.queryIntentActivities(normal, PackageManager.MATCH_ALL));

        Collections.sort(apps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });

        for (ResolveInfo info : apps) {
            appRow.addView(makeAppTile(info), new LinearLayout.LayoutParams(dp(142), dp(126)));
        }
        if (appRow.getChildCount() > 0) appRow.getChildAt(0).requestFocus();
    }

    private void addUnique(List<ResolveInfo> source) {
        for (ResolveInfo r : source) {
            String pkg = r.activityInfo.packageName;
            boolean exists = false;
            for (ResolveInfo old : apps) {
                if (old.activityInfo.packageName.equals(pkg)) { exists = true; break; }
            }
            if (!exists && !pkg.equals(getPackageName())) apps.add(r);
        }
    }

    private void playFocusSound() {
        long now = System.currentTimeMillis();
        if (tone != null && now - lastFocusTone > 75) {
            lastFocusTone = now;
            try { tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 42); } catch (Exception ignored) {}
        }
    }

    private View makeAppTile(final ResolveInfo info) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setFocusable(true);
        tile.setFocusableInTouchMode(true);
        tile.setBackground(shape(Color.rgb(24, 34, 53), 19, Color.rgb(48, 63, 88), 1));
        tile.setPadding(dp(9), dp(10), dp(9), dp(8));

        LinearLayout.LayoutParams tileParams = (LinearLayout.LayoutParams) tile.getLayoutParams();
        tileParams = new LinearLayout.LayoutParams(dp(142), dp(126));
        tileParams.rightMargin = dp(12);
        tile.setLayoutParams(tileParams);

        ImageView icon = new ImageView(this);
        try { icon.setImageDrawable(info.loadIcon(getPackageManager())); } catch (Exception ignored) {}
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        tile.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView name = label(info.loadLabel(getPackageManager()).toString(), 13, WHITE, true);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, dp(36));
        np.topMargin = dp(7);
        tile.addView(name, np);

        tile.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { launchApp(info); }
        });
        tile.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean focused) {
                if (focused) playFocusSound();
                v.animate().scaleX(focused ? 1.075f : 1f).scaleY(focused ? 1.075f : 1f)
                    .setDuration(145).start();
                v.setBackground(shape(
                    focused ? Color.rgb(42, 61, 88) : Color.rgb(24, 34, 53),
                    19,
                    focused ? Color.rgb(126, 216, 255) : Color.rgb(48, 63, 88),
                    focused ? 2 : 1
                ));
            }
        });
        return tile;
    }

    private void launchApp(ResolveInfo info) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(info.activityInfo.packageName);
        try {
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
            } else {
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
                i.setPackage(info.activityInfo.packageName);
                startActivity(i);
            }
        } catch (Exception ignored) {}
    }
}
