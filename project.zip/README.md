# Orbit TV Launcher

A lightweight, ad-free Android TV home launcher built with native Android Views (no ad SDKs, analytics SDKs, or network permissions).

## Features
- Android TV HOME launcher intent
- TV remote D-pad focus and OK-to-launch support
- Discovers Android TV and standard launcher apps
- Large app tiles with focus animation
- Clock/date header
- Dark gradient interface
- No advertisements or tracking libraries

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync (Android Gradle Plugin 8.7.3; compile SDK 35).
3. Connect an Android TV device or use an Android TV emulator.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the APK on the TV.

## Set as default launcher
1. Open Orbit TV once.
2. Press the TV remote's Home button.
3. If Android shows a home-app chooser, select **Orbit TV** and choose **Always**.
4. To switch back, open Settings > Apps > Default apps > Home app (wording varies by TV).

## Notes
- Some manufacturer/system apps may not expose a launchable activity and therefore may not appear.
- `QUERY_ALL_PACKAGES` is used so the sideloaded launcher can discover installed apps. App-store distribution may require a narrower package-visibility design.
- This project is source code; it is not a prebuilt APK. Build it with Android Studio.

## Version 1.1 UI update
- Refreshed with a minimalist, Apple TV-inspired dark interface (original layout, not Apple's assets).
- Horizontal app shelf for easier D-pad navigation.
- Subtle short focus tone when moving focus between app tiles.
- Focus animation and highlighted outline.
